#           ifndef _IoTVision_h
#define _IoTVision_h

// Cho một số đoạn Serial.print hiển thị debug.
//#define debug

#endif
